package com.micro.hotelservice.exception;

public class ResourceNotFoundEception extends RuntimeException{
	
	public ResourceNotFoundEception() {
		super("Resource not found");
	}
	
	public ResourceNotFoundEception(String message) {
		super(message);
	}
	
	
}
