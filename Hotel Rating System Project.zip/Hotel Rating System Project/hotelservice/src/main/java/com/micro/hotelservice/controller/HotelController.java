package com.micro.hotelservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.micro.hotelservice.entity.Hotel;
import com.micro.hotelservice.services.HotelService;


@RestController
@RequestMapping("/hotel")
public class HotelController {
	
	@Autowired
	private HotelService hotelService;

	// create hotel
	@PostMapping("/add")
	public ResponseEntity<Hotel> createUser(@RequestBody Hotel hotel) {
		Hotel hotel1 = hotelService.create(hotel);
		return ResponseEntity.status(HttpStatus.CREATED).body(hotel1);
	}

	// get single hotel
	@GetMapping("/{hotelId}")
	public ResponseEntity<Hotel> getUserbyId(@PathVariable String hotelId) {
		Hotel hotel1 = hotelService.getHotelbyId(hotelId);
		return ResponseEntity.ok(hotel1);
	}

	// get all hotel
	@GetMapping("/all")
	public ResponseEntity<List<Hotel>> getAllHotels() {
		List<Hotel> allusers = hotelService.getAllHotels();
		return ResponseEntity.ok(allusers);
	}
	
}
