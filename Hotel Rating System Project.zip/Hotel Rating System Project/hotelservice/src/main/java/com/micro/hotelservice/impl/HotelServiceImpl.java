package com.micro.hotelservice.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.micro.hotelservice.entity.Hotel;
import com.micro.hotelservice.exception.ResourceNotFoundEception;
import com.micro.hotelservice.repo.HotelRepository;
import com.micro.hotelservice.services.HotelService;

@Service
public class HotelServiceImpl implements HotelService {

	@Autowired
	private HotelRepository hotelRepo;

	@Override
	public Hotel create(Hotel hotel) {
		// generate unique hotel Id
		String randomHotelId = UUID.randomUUID().toString();
		hotel.setId(randomHotelId);
		return hotelRepo.save(hotel);
	}

	@Override
	public List<Hotel> getAllHotels() {
		return hotelRepo.findAll();
	}

	@Override
	public Hotel getHotelbyId(String hotelId) {
		return hotelRepo.findById(hotelId).orElseThrow(() -> new ResourceNotFoundEception("Hotel not found on server with hotelId : "+ hotelId));
	}

}
