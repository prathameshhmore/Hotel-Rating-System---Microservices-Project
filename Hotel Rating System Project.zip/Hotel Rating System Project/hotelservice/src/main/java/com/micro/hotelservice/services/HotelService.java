package com.micro.hotelservice.services;

import java.util.List;

import com.micro.hotelservice.entity.Hotel;

public interface HotelService {
	
	// create
	Hotel create(Hotel hotel);
	
	// get all
	List<Hotel> getAllHotels();
	
	// get single
	Hotel getHotelbyId(String hotelId);

	
}
