package com.micro.ratingservice.service;

import java.util.List;

import com.micro.ratingservice.entity.Rating;

public interface RatingService {
	
	//create
	Rating create(Rating rating);
	
	// get all ratings
	List<Rating>getRatings(); 
	
	// get all by id
	List<Rating> getRatingbyUserId(String userId);
	
	// get all by hotel
	List<Rating> getRatingByHotelId(String hotelId);
}
