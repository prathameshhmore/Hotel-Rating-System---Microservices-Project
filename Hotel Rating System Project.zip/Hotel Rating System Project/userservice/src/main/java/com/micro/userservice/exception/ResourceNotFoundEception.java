package com.micro.userservice.exception;

public class ResourceNotFoundEception extends RuntimeException{
	
	public ResourceNotFoundEception() {
		super("Resource not found on server!!");
	}
	
	public ResourceNotFoundEception(String message) {
		super(message);
	}
	
}
