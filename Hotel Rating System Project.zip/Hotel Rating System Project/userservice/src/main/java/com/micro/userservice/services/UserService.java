package com.micro.userservice.services;

import java.util.List;

import com.micro.userservice.entity.User;

public interface UserService {
	
	// create
	User createUser(User user);
	
	// get all users
	List<User> getAllUsers();
	
	// get user by id
	User getUserbyId(String userId);

	
	// update
	
	//delete
}
