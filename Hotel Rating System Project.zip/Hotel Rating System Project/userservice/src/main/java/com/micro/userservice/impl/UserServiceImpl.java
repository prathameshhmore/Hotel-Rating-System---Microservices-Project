package com.micro.userservice.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.micro.userservice.entity.Hotel;
import com.micro.userservice.entity.Rating;
import com.micro.userservice.entity.User;
import com.micro.userservice.exception.ResourceNotFoundEception;
import com.micro.userservice.feignInterface.HotelService;
import com.micro.userservice.repo.UserRepository;
import com.micro.userservice.services.UserService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private HotelService hotelService;
	
	private Logger logger= LoggerFactory.getLogger(UserService.class);

	@Override
	public User createUser(User user) {
		//generate unique userId
		String randomUserId = UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		return userRepo.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}
		
	@Override
	@Retry(name = "ratingHotelServiceRetry", fallbackMethod = "ratingHotelFallback")
	// Only after all 3 retry attempts fail, the fallbackMethod (ratingHotelFallback) is called.
	@CircuitBreaker(name = "ratingHotelBreaker", fallbackMethod = "ratingHotelFallback")
	@RateLimiter(name = "userRateLimiter", fallbackMethod = "ratingHotelFallback")
	public User getUserbyId(String userId) {
		User user= userRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundEception("User not found on server with userId : "+ userId));
		
		// here calling other services via resttemplate
		
		// fetch rating of above user from RATING SERVICE
		// http://localhost:8083/rating/user/332371b0-f5f8-48b0-8213-d42b8a8ed7f4
		
		Rating[] ratingsOfUser= restTemplate.getForObject("http://RATING-SERVICE/rating/user/"+ user.getUserId(), Rating[].class);
		logger.info("{} ",ratingsOfUser);
		
		List<Rating> ratings = Arrays.stream(ratingsOfUser).toList();
		
		List<Rating> ratingList = ratings.stream().map(rating -> {
			// api call to hotel service to get the hotel
			// http://localhost:8081/hotel/e243813d-1ba4-4b97-a3d7-c549156d6623
			
			//ResponseEntity<Hotel> forEntity= restTemplate.getForEntity("http://HOTEL-SERVICE/hotel/"+ rating.getHotelId(), Hotel.class);	
			Hotel hotel = hotelService.getHotel(rating.getHotelId());
			//logger.info("response status code: {} ",forEntity.getStatusCode());
			
			rating.setHotel(hotel);
			return rating;
		}).collect(Collectors.toList());
			
		user.setRatings(ratingList);
		return user;
	}
	
	// IMP
	// creating fallback method for circuit breaker
	// this method is executed if rating or hotel services are down
	public User ratingHotelFallback(String userIdString, Throwable ex){
		logger.info("Fallback is executed because service is down: {}", ex.getMessage());
		logger.error(">>>>> Fallback triggered after retries failed: {}", ex.getMessage());
	    logger.warn("Fallback called for userId={}, reason={}", userIdString, ex.toString());
		User user= User.builder().email("dummy@gmail.com").name("Dummy").about("This user is created because some services are down").userId("1234").build();
		return user;
	}

}
